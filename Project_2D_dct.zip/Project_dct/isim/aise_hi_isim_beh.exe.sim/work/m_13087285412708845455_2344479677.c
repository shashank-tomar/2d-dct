/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/ise/Project/aise_hi.v";



static void Cont_25_0(char *t0)
{
    char t4[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    char *t14;
    unsigned int t15;
    unsigned int t16;
    char *t17;

LAB0:    t1 = (t0 + 2360U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(25, ng0);
    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    memcpy(t4, t3, 8);
    t2 = (t0 + 2760);
    t5 = (t2 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memset(t8, 0, 8);
    t9 = 65535U;
    t10 = t9;
    t11 = (t4 + 4);
    t12 = *((unsigned int *)t4);
    t9 = (t9 & t12);
    t13 = *((unsigned int *)t11);
    t10 = (t10 & t13);
    t14 = (t8 + 4);
    t15 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t15 | t9);
    t16 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t16 | t10);
    xsi_driver_vfirst_trans(t2, 0, 15);
    t17 = (t0 + 2680);
    *((int *)t17) = 1;

LAB1:    return;
}


extern void work_m_13087285412708845455_2344479677_init()
{
	static char *pe[] = {(void *)Cont_25_0};
	xsi_register_didat("work_m_13087285412708845455_2344479677", "isim/aise_hi_isim_beh.exe.sim/work/m_13087285412708845455_2344479677.didat");
	xsi_register_executes(pe);
}
